import { Component } from '@angular/core';

@Component({
  selector: 'app-flights-round-trip',
  templateUrl: './flights-round-trip.component.html',
  styleUrls: ['./flights-round-trip.component.scss']
})
export class FlightsRoundTripComponent {

}
