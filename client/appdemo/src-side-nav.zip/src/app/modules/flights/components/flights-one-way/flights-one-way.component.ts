import { Component } from '@angular/core';

@Component({
  selector: 'app-flights-one-way',
  templateUrl: './flights-one-way.component.html',
  styleUrls: ['./flights-one-way.component.scss']
})
export class FlightsOneWayComponent {

}
