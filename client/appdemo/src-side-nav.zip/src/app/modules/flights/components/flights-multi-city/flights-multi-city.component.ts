import { Component } from '@angular/core';

@Component({
  selector: 'app-flights-multi-city',
  templateUrl: './flights-multi-city.component.html',
  styleUrls: ['./flights-multi-city.component.scss']
})
export class FlightsMultiCityComponent {

}
